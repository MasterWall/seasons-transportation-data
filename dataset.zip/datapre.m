clc
a=data12';
b=reshape(a(1:length(a)),4,[]);
DEC=[sum(b)]'